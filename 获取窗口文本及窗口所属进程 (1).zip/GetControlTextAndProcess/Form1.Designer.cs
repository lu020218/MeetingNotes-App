﻿namespace GetControlTextAndProcess
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_cText = new System.Windows.Forms.TextBox();
            this.textBox_cHandle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_cClassName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_pClassName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_pHandle = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_pTitle = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_fileName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_id = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_description = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_Company = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(178, 274);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(245, 12);
            this.label4.TabIndex = 15;
            this.label4.Text = "开启捕捉后，将鼠标移动到控件上即可显示。";
            // 
            // textBox_cText
            // 
            this.textBox_cText.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_cText.Location = new System.Drawing.Point(83, 50);
            this.textBox_cText.Name = "textBox_cText";
            this.textBox_cText.ReadOnly = true;
            this.textBox_cText.Size = new System.Drawing.Size(505, 21);
            this.textBox_cText.TabIndex = 14;
            // 
            // textBox_cHandle
            // 
            this.textBox_cHandle.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_cHandle.Location = new System.Drawing.Point(83, 20);
            this.textBox_cHandle.Name = "textBox_cHandle";
            this.textBox_cHandle.ReadOnly = true;
            this.textBox_cHandle.Size = new System.Drawing.Size(62, 21);
            this.textBox_cHandle.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 12;
            this.label3.Text = "控件文本";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 10;
            this.label1.Text = "控件句柄";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(200, 235);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(201, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "开始捕捉(Alt+S)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_cClassName
            // 
            this.textBox_cClassName.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_cClassName.Location = new System.Drawing.Point(235, 20);
            this.textBox_cClassName.Name = "textBox_cClassName";
            this.textBox_cClassName.ReadOnly = true;
            this.textBox_cClassName.Size = new System.Drawing.Size(353, 21);
            this.textBox_cClassName.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(181, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 16;
            this.label2.Text = "控件类名";
            // 
            // textBox_pClassName
            // 
            this.textBox_pClassName.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_pClassName.Location = new System.Drawing.Point(235, 93);
            this.textBox_pClassName.Name = "textBox_pClassName";
            this.textBox_pClassName.ReadOnly = true;
            this.textBox_pClassName.Size = new System.Drawing.Size(353, 21);
            this.textBox_pClassName.TabIndex = 19;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(169, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 18;
            this.label5.Text = "父控件类名";
            // 
            // textBox_pHandle
            // 
            this.textBox_pHandle.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_pHandle.Location = new System.Drawing.Point(83, 93);
            this.textBox_pHandle.Name = "textBox_pHandle";
            this.textBox_pHandle.ReadOnly = true;
            this.textBox_pHandle.Size = new System.Drawing.Size(62, 21);
            this.textBox_pHandle.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 20;
            this.label6.Text = "父控件句柄";
            // 
            // textBox_pTitle
            // 
            this.textBox_pTitle.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_pTitle.Location = new System.Drawing.Point(83, 124);
            this.textBox_pTitle.Name = "textBox_pTitle";
            this.textBox_pTitle.ReadOnly = true;
            this.textBox_pTitle.Size = new System.Drawing.Size(505, 21);
            this.textBox_pTitle.TabIndex = 23;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 22;
            this.label7.Text = "父控件标题";
            // 
            // textBox_fileName
            // 
            this.textBox_fileName.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_fileName.Location = new System.Drawing.Point(83, 200);
            this.textBox_fileName.Name = "textBox_fileName";
            this.textBox_fileName.ReadOnly = true;
            this.textBox_fileName.Size = new System.Drawing.Size(505, 21);
            this.textBox_fileName.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 203);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 28;
            this.label8.Text = "文件路径";
            // 
            // textBox_id
            // 
            this.textBox_id.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_id.Location = new System.Drawing.Point(83, 167);
            this.textBox_id.Name = "textBox_id";
            this.textBox_id.ReadOnly = true;
            this.textBox_id.Size = new System.Drawing.Size(62, 21);
            this.textBox_id.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 170);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 26;
            this.label9.Text = "进程ID";
            // 
            // textBox_description
            // 
            this.textBox_description.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_description.Location = new System.Drawing.Point(217, 167);
            this.textBox_description.Name = "textBox_description";
            this.textBox_description.ReadOnly = true;
            this.textBox_description.Size = new System.Drawing.Size(100, 21);
            this.textBox_description.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(163, 170);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 24;
            this.label10.Text = "文件描述";
            // 
            // textBox_Company
            // 
            this.textBox_Company.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_Company.Location = new System.Drawing.Point(386, 167);
            this.textBox_Company.Name = "textBox_Company";
            this.textBox_Company.ReadOnly = true;
            this.textBox_Company.Size = new System.Drawing.Size(202, 21);
            this.textBox_Company.TabIndex = 31;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(330, 170);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 30;
            this.label11.Text = "公司名称";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 302);
            this.Controls.Add(this.textBox_Company);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox_fileName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox_id);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox_description);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox_pTitle);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox_pHandle);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_pClassName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_cClassName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_cText);
            this.Controls.Add(this.textBox_cHandle);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "从鼠标坐标获取控件信息及所属进程信息";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_cText;
        private System.Windows.Forms.TextBox textBox_cHandle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox_cClassName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_pClassName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_pHandle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_pTitle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_fileName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_id;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_description;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_Company;
        private System.Windows.Forms.Label label11;
    }
}

