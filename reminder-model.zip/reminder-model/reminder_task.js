const ReminderData = require('./reminder_data');
const cronParser = require('cron-parser');
const UniqueArray = require('./UniqueArray');
import { v4 as uuidv4 } from 'uuid';

// 依据任务开始时间、提前提醒时间以及重复类型生成cron表达式
function generateCronExpression(timestamp, advanceTimeInSeconds, repeatType) {
    const startDate = new Date(timestamp - advanceTimeInSeconds * 1000);
    
    const minute = startDate.getUTCMinutes();
    const hour = startDate.getUTCHours();
    const day = startDate.getUTCDate();
    const month = startDate.getUTCMonth() + 1; // getUTCMonth returns 0-11
    const dayOfWeek = startDate.getUTCDay(); // getUTCDay returns 0-6 (Sunday-Saturday)
  
    let cronExpression = '';
  
    switch (repeatType) {
      case 'daily':
        // 每天
        cronExpression = `${minute} ${hour} * * *`;
        break;
      case 'weekday':
        // 每个工作日 (周一到周五)
        cronExpression = `${minute} ${hour} * * 1-5`;
        break;
      case 'weekly':
        // 每周
        cronExpression = `${minute} ${hour} * * ${dayOfWeek}`;
        break;
      case 'monthly':
        // 每月
        cronExpression = `${minute} ${hour} ${day} * *`;
        break;
      case 'yearly':
        // 每年
        cronExpression = `${minute} ${hour} ${day} ${month} *`;
        break;
      default:
        throw new Error('Invalid repeat type');
    }
  
    return cronExpression;
}

// 解析cron表达式，获取指定时间范围内的任务触发时间戳数组
function generateTimestampsFromCronExpression(cronExpression, startDate, endDate) {
    const options = {
        currentDate: startDate,
        endDate: endDate,
        iterator: true,
    };

    const timestamps = [];
    const interval = cronParser.parseExpression(cronExpression, options);

    while (true) {
        try {
            const next = interval.next();
            if (!next || next.getTime() > endDate.getTime()) break;
            timestamps.push(next.getTime());
        } catch (error) {
            console.error('Error parsing cron expression:', error.message);
            break;
        }
    }

    return timestamps;
}

// 依据cron表达式获取指定时间段内的任务开始时间戳数组
function getTimestampsFromCronExpression(taskStartTime, advanceTimeInSeconds, repeatType, rangeStartTime, rangeEndTime) {
    const cronExpression = generateCronExpression(taskStartTime, advanceTimeInSeconds, repeatType);
  
    const options = {
      currentDate: new Date(rangeStartTime),
      endDate: new Date(rangeEndTime),
      iterator: true,
    };
  
    const timestamps = [];
    const interval = cronParser.parseExpression(cronExpression, options);
  
    while (true) {
      try {
        const obj = interval.next();
        const taskTimestamp = obj.value.getTime() + (advanceTimeInSeconds * 1000);
        if (taskTimestamp > rangeEndTime) break;
        timestamps.push(taskTimestamp);
      } catch (error) {
        break;
      }
    }
  
    return timestamps;
}

let ReminderTask = {
    init: function (data, dbPath) {
        if (ReminderData.Connect(dbPath)) {
            if (ReminderData.Init()) {
                let ret = ReminderData.InsertTag(data.tags);
                ret = ReminderData.InsertTodoTask(data.tasks);
                ret = ReminderData.InsertTag2TodoTask(data.tag_todo_tasks);
                ret = ReminderData.InsertTodoTaskChangeRecord(data.todo_task_change_records);
                ret = ReminderData.InsertReminderEvent(data.reminder_event);
                ret = ReminderData.InsertReminderEventHistory(data.reminder_event_history);
            }
        }
    },
    // 依据主任务生成提醒事件
    generateReminderEvent: function (task) {
        let cron = generateCronExpression(task.start_time, task.repetition_type);
        const uuid = uuidv4();
        const currentTimestamp = Date.now();

        let reminderEvent = {
            id: uuid,
            task_id: task.id,
            title: task.title,
            cron: cron,
            content: task.content,
            reminder_type: task.reminder_type,
            scheduled_id: uuid,
            created_time: currentTimestamp,
            updated_time: currentTimestamp,
            status: '',
            trigger_time: '',
            target_data_address: ''
        };
        ReminderData.InsertReminderEvent([reminderEvent])
    },
    // 查询任务接口，通过提醒事件表与提醒事件历史记录表，获取时间段内的taskid数组、task status
    // 通过taskid数组获取时间段内所有任务，任务结束时间 - 任务开始时间 = 任务时长
    // 通过重复类型、任务开始时间、时间段
    getReminderTask: function (begin, end) {
        let events = ReminderData.QueryReminderEvent(`trigger_time >= ${begin} and trigger_time <= ${end}`);
        let eventhis = ReminderData.QueryReminderEventHistory(`reminder_time >= ${begin} and reminder_time <= ${end}`);

        let taskIdSet = new Set();
        let taskUniArray = new UniqueArray('task_id');
        events.forEach(el => {
            taskIdSet.add(el.task_id);
            taskUniArray.add({
                task_id: el.task_id,
                start_time: el.start_time,
                end_time: el.end_time
            });
        });
        eventhis.forEach(el => {
            taskIdSet.add(el.task_id);
            taskUniArray.add({
                task_id: el.task_id,
                start_time: el.start_time,
                end_time: el.end_time
            });
        });

        let tasks = [];
        const idList = Array.from(taskIdSet).join(',');
        let task_list = ReminderData.QueryTodoTask(`id in (${idList})`);
        if (task_list) {
            task_list.forEach(task => {
                let task_temp = taskUniArray.get(task.id);
                if (task_temp) {
                    let t = {
                        id: task.id,
                        task_type: task.task_type,
                        title: task.title,
                        content: task.content,
                        start_time: task_temp.start_time,
                        end_time: task_temp.end_time,
                        advanced_time: [],
                        repetition_type: task.repetition_type,
                        message_type: task.message_type,
                        end_type: task.end_type,
                        end_value: task.end_value,
                        user_id: task.user_id
                    };
    
                    tasks.push(t);
                }
            });
        }

        return tasks;
    },
}