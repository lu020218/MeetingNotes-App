#!/usr/bin/python3

import os
import json
import sys
import time
import logging
import argparse
import shutil
import util

def make_app(base_dir:str, unpacked_path:str, dest_path:str) -> bool:
    """
    将要安装的文件目录压缩成app.7z
    """
    os.chdir(base_dir)    
    util.remove_file(dest_path)
    src_files = f"{unpacked_path}\\*"
    cmd = f"7z.exe a \"{dest_path}\" \"{src_files}\" -r"
    ret = util.run_cmd_wait_ret(cmd, True)    
    if not ret:
        logging.error(f"make_app failed")
        return False
    return True

def make_nsis_code(dest_path:str, unpacked_path:str) -> bool:
    """
    遍历文件夹, 生成安装过程中的nsis文件释放脚本
    """
    total_count = util.get_file_count(unpacked_path)
    content = ""
    dest_base_dir = "$INSTDIR"
    # 遍历首层文件
    curr_count = 0
    dict_dir = {}
    tmp = {}
    
    files = os.listdir(unpacked_path)
    for file in files:
        file_path = os.path.join(unpacked_path, file)
        # dir
        if os.path.isfile(file_path):
            curr_count += 1
            content += f"Push {total_count}  \n"
            content += f"Push {curr_count}  \n"
            content += "Call ExtractCallback \n"
            content += f"File \"{file_path}\"  \n"
        else:
            if os.path.isdir(file_path):
                dict_dir[file_path] = 1
                tmp[file_path] = 1

    # 遍历目录
    for path in tmp.keys():
        util.scan_directories(path, dict_dir)
    # 遍历文件
    for path in dict_dir.keys():
        tmp_path = path.replace(unpacked_path, "$INSTDIR")
        content += f"SetOutPath \"{tmp_path}\" \n"
        files = os.listdir(path)
        for file in files:
            file_path = os.path.join(path, file)
            if os.path.isfile(file_path):
                curr_count += 1
                content += f"Push {total_count}  \n"
                content += f"Push {curr_count}  \n"
                content += "Call ExtractCallback \n"
                content += f"File \"{file_path}\"  \n"

    content += f"Push {total_count}  \n"
    content += f"Push {total_count}  \n"
    content += "Call ExtractCallback \n"
    logging.info(f"total_count({total_count}, curr_count({curr_count})")
    util.write_content(dest_path, content)
    return True
    
def write_pre_define(base_dir:str, args: argparse.ArgumentParser) -> bool:
    """
    将公共的需要传递给nsi文件的预定义宏写到预定义文件中 
    """
    pre_define_path = f"{base_dir}\SetupScripts\{args.project_name}\pre_define.nsh"
    logging.info(pre_define_path)
    util.remove_file(pre_define_path)
    content = ""
    if args.PRODUCT_NAME is not None:
        content += f'!define /ifndef PRODUCT_NAME               "{args.PRODUCT_NAME}"\n'
    if args.PRODUCT_NAME_EN is not None:
        content += f'!define /ifndef PRODUCT_NAME_EN               "{args.PRODUCT_NAME_EN}"\n'
    
    if args.PRODUCT_PATHNAME is not None:
        content += f'!define /ifndef PRODUCT_PATHNAME               "{args.PRODUCT_PATHNAME}"\n'
    if args.INSTALL_APPEND_PATH is not None:
        content += f'!define /ifndef INSTALL_APPEND_PATH            "{args.INSTALL_APPEND_PATH}"\n'
    if args.INSTALL_DEFALT_SETUPPATH is not None:
        content += f'!define /ifndef INSTALL_DEFALT_SETUPPATH       "{args.INSTALL_DEFALT_SETUPPATH}"\n'
    if args.EXE_NAME is not None:
        content += f'!define /ifndef EXE_NAME                       "{args.EXE_NAME}"\n'
    if args.PRODUCT_VERSION is not None:
        content += f'!define /ifndef PRODUCT_VERSION                   "{args.PRODUCT_VERSION}"\n'
    if args.PRODUCT_PUBLISHER is not None:
        content += f'!define /ifndef PRODUCT_PUBLISHER               "{args.PRODUCT_PUBLISHER}"\n'
    if args.PRODUCT_LEGAL is not None:
        content += f'!define /ifndef PRODUCT_LEGAL                   "{args.PRODUCT_LEGAL}"\n'
    if args.INSTALL_MODE_ALL_USERS is not None:
        content += f'!define /ifndef INSTALL_MODE_ALL_USERS         "{args.INSTALL_MODE_ALL_USERS}"\n'
    if args.INSTALL_EXECUTION_LEVEL is not None:
        content += f'!define /ifndef INSTALL_EXECUTION_LEVEL        "{args.INSTALL_EXECUTION_LEVEL}"\n'
    if args.INSTALL_OUTPUT_NAME is not None:
        content += f'!define /ifndef INSTALL_OUTPUT_NAME            "{args.INSTALL_OUTPUT_NAME}"\n'
    if args.INSTALL_LOCATION_KEY is not None:
        content += f'!define /ifndef INSTALL_LOCATION_KEY           "{args.INSTALL_LOCATION_KEY}"\n'
    if args.INSTALL_DEFAULT_AUTORUN is not None:
        content += f'!define /ifndef INSTALL_DEFAULT_AUTORUN        {args.INSTALL_DEFAULT_AUTORUN}\n'
    if args.INSTALL_DEFAULT_SHOTCUT is not None:
        content += f'!define /ifndef INSTALL_DEFAULT_SHOTCUT        {args.INSTALL_DEFAULT_SHOTCUT}\n'
    if args.TEST_SLEEP is not None:
        content += f'!define /ifndef TEST_SLEEP                       {args.TEST_SLEEP}\n'
    if args.INSTALL_DOWNLOAD_BASEURL is not None:
        content += f'!define /ifndef INSTALL_DOWNLOAD_BASEURL        "{args.INSTALL_DOWNLOAD_BASEURL}"\n'
    
    util.write_content(pre_define_path, content)

def adjust_version(version:str) -> str:
    """
    有些软件自身只有三段的版本号, 但NSIS要求要4段, 碰到这种情况要加上
    """
    if version is None:
        return version
    # 判断如果不是4段的, 末尾加0
    version_data = version.split('.')
    if len(version_data) < 4:
        return version + '.0'
    return version

def sign_file(base_dir:str, bin_file_path:str) -> bool:
    """
    文件签名脚本, 具体的实现在Sign目录下的bat脚本中
    """
    os.chdir(f"{base_dir}\\Sign")
    logging.info(f"sign {bin_file_path}")
    cmd = f"Call sign.bat \"{bin_file_path}\""
    ret = util.run_cmd_wait_ret(cmd, True)
    os.chdir(base_dir)
    if not ret:
        logging.error(f"sign_file failed: {bin_file_path}")
        return False
    return True

def try_sleep(seconds:int):
    time.sleep(seconds)

def generate_uninstall_and_sign(base_dir:str, args: argparse.ArgumentParser) -> bool:
    """
    生成卸载程序并根据配置签名
    """
    if args.auto_write_uninst:
        return True
    uninstall_file_path = f".\\Output\\{args.uninst_file_name}"    
    util.remove_file(uninstall_file_path)
    try_sleep(3)
    nsi_path = f".\\SetupScripts\\{args.project_name}\\soft_setup.nsi"
    # ".\NSIS\makensis.exe" /DBUILD_FOR_GENERATE_UNINST=1 %more_macro% %auto_write_uninst_macro% /DUNINST_FILE_NAME=%uninst_name% /DINSTALL_OUTPUT_NAME=%output_filename% %more_macro% "%nsi_path%"
    cmd = f"\".\\NSIS\\makensis.exe\" /DBUILD_FOR_GENERATE_UNINST=1 /DUNINST_FILE_NAME={args.uninst_file_name} \"{nsi_path}\"" 
    ret = util.run_cmd_wait_ret(cmd, True)    
    if not ret:
        logging.error(f"generate uninstall failed")
        return False
    # 释放uninst.exe
    cmd =f".\\Output\\{args.INSTALL_OUTPUT_NAME}"
    ret = util.run_cmd_wait_ret(cmd, True)    
    if not ret:
        logging.error(f"extract uninstall failed")
        return False

    if args.need_sign:        
        output_filepath = f"..\\Output\\{args.uninst_file_name}"
        ret = sign_file(base_dir, output_filepath)    
        if not ret:
            logging.error(f"sign uninstall failed")
            return False
        os.chdir(base_dir)
    dst_file_path = f".\\{args.files_toinstall_name}\\{args.uninst_file_name}"
    util.remove_file(dst_file_path)
    shutil.copy(uninstall_file_path, dst_file_path)
    return True

def generate_setup_and_sign(base_dir:str, args: argparse.ArgumentParser) -> bool:
    """
    生成最终的安装程序, 并签名
    """
    unpacked_path = f"{base_dir}\\{args.files_toinstall_name}"
    nsi_path = f".\\SetupScripts\\{args.project_name}\\soft_setup.nsi"

    os.chdir(base_dir)

    more_macro = ""
    auto_write_uninst_macro = ""    
    if args.auto_write_uninst:
        auto_write_uninst_macro="/DAUTO_WRITE_UNINSTALL_FILE=1"
    
    # 判断是否要生成
    if args.package_mode == 1:
        dest_7z_path = f"{base_dir}\\SetupScripts\\app.7z"
        ret = make_app(base_dir, unpacked_path, dest_7z_path)
        if not ret:
            logging.error("make_app failed")
            return False
    elif args.package_mode == 2:
        dest_nsh_path = f"{base_dir}\\SetupScripts\\app.nsh"
        util.remove_file(dest_nsh_path)
        ret = make_nsis_code(dest_nsh_path, unpacked_path)
        if not ret:
            logging.error("make_nsis_code failed")
            return False
        more_macro="/DINSTALL_WITH_NO_NSIS7Z=1"
    elif args.package_mode == 3:
        dest_7z_path = f"{base_dir}\\Output\\app.7z"
        ret = make_app(base_dir, unpacked_path, dest_7z_path)
        if not ret:
            logging.error("make_app failed")
            return False
        dest_nsh_path = f"{base_dir}\\SetupScripts\\app.nsh"
        util.write_content(dest_nsh_path, "\n")
        dest_ini_path = f"{base_dir}\\Output\\config.ini"
        util.remove_file(dest_ini_path)
        cmd = '"./Helper/NSISHelper.exe" --mode="generate_online_config" --src="' + dest_7z_path + '" --dst="' + dest_ini_path + '"'
        ret = util.run_cmd_wait_ret(cmd, True)
        if not ret:
            logging.error("generate update failed")
            return False
        more_macro="/DINSTALL_DOWNLOAD_7Z=1"
    else:
        logging.error("wrong package_mode")
        return False
    
    output_filepath = f".\\Output\\{args.INSTALL_OUTPUT_NAME}"
    util.remove_file(output_filepath)
    try_sleep(3)
    
    cmd = f"\".\\NSIS\\makensis.exe\" {auto_write_uninst_macro} /DUNINST_FILE_NAME={args.uninst_file_name} {more_macro} \"{nsi_path}\"" 
    ret = util.run_cmd_wait_ret(cmd, True)    
    if not ret:
        logging.error(f"generate setup failed")
        return False
    
    if args.need_sign:
        output_filepath = f"..\\Output\\{args.INSTALL_OUTPUT_NAME}"
        ret = sign_file(base_dir, output_filepath)    
        if not ret:
            logging.error(f"sign setup failed")
            return False
    return True

def generate_latest_xml(base_dir:str, latest_version:str, args: argparse.ArgumentParser) -> bool:
    """
    生成electron-updater升级所需要的配置文件
    """
    if not args.generate_latest_file:
        return True
    if latest_version is None:
        logging.error("invalid latest_version")
        return False

    os.chdir(base_dir)
    output_filepath = f".\\Output\\{args.INSTALL_OUTPUT_NAME}"
    latest_path = ".\Output\latest.yml"
    util.remove_file(latest_path)
    cmd = f".\\Helper\\NSISHelper.exe --mode=\"generate_electron_update_config\" --src=\"{output_filepath}\" --dst=\"{latest_path}\" --version=\"{latest_version}\""
    ret = util.run_cmd_wait_ret(cmd, True)    
    if not ret:
        logging.error(f"generate_latest_xml failed")
        return False
    return True

def generate_skin_and_language(base_dir: str, project_name:str) -> bool:
    """
    借助NSISHelper生成皮肤和语言
    """
    os.chdir(base_dir)
    n = 1
    cmd = '.\\Helper\\NSISHelper.exe --project="' + project_name +'" --mode="run" --type="all"'
    ret = util.run_cmd_wait_ret(cmd, True)    
    if not ret:
        logging.error(f"generate_skin_and_language failed")
        return False
    return True


def build_for_electron(base_dir:str, args: argparse.ArgumentParser) -> bool:
    """
    本函数用于读取electron的打包配置, 应用到我们的安装包上来, 另外会触发electron-builder进行打包, 将打好的文件复制到我们的目录下
    如果你的electron打包配置不是这样的, 那么请自行调整本函数的读取逻辑
    """
    build_path = args.electron_build_path
    if build_path is None:
        build_path = f"{base_dir}\\NiuNiuCaptureElectronDemo"

    unpacked_file_path =f"{build_path}\dist\win-unpacked"

    package_json_path = build_path + "\package.json"
    load_dict = {}
    with open(package_json_path, "r", encoding="utf8") as load_f:
        load_dict = json.load(load_f)
    # 以下几项信息, 我们均尝试从electron-builder的配置文件package.json中读取, 如果你不想从里面读取, 请指定名称, 并注释掉下面读取的代码 (guid与版本号必需读取)
    # 应用程序名称, 用于作为程序安装路径的扩展路径, 同时也作为主程序名称
    app_name=load_dict["name"]
    if app_name is None or len(app_name) < 1:
        logging.error("get app_name failed")
        return False
    # 软件版本号
    electron_app_version=load_dict["version"]
    if electron_app_version is None or len(electron_app_version) < 1:
        logging.error("get electron_app_version failed")
        return False
    # electron程序中打包的guid, 用于安装在注册表中的key(卸载与软件信息)
    try:
        electron_guid=load_dict["build"]["nsis"]["guid"]
    except:
        logging.error("get electron_guid failed")
        return False
    args.EXE_NAME = app_name + ".exe"
    args.PRODUCT_VERSION = electron_app_version
    args.PRODUCT_PATHNAME = app_name
    args.INSTALL_OUTPUT_NAME=f"{app_name}_Setup_{electron_app_version}.exe"
    args.generate_latest_file = True

    os.chdir(build_path)
    # 执行Electron编译打包
    cmd = "npm run build"
    ret = util.run_cmd_wait_ret(cmd, True)    
    if not ret:
        logging.error(f"npm build failed")
        return False
    os.chdir(base_dir)
    logging.info("npm build finished")

    # 复制打包好的文件到我们的目录下
    args.files_toinstall_name = "ElectronInstall"
    files_toinstall_path = f"{base_dir}\{args.files_toinstall_name}"
    try:
        if os.path.exists(files_toinstall_path):
            shutil.rmtree(files_toinstall_path)
        os.mkdir(files_toinstall_path)
        util.deep_copy(unpacked_file_path, files_toinstall_path)
    except Exception as e:
        logging.exception(e)
        return False

    return True
