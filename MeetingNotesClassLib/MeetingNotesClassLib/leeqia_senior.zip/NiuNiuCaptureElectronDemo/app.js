﻿const { shell, clipboard } = require('electron');
const { remote } = require('electron');
const path = require("path");
const child = require('child_process');
var fs = require('fs');
function openScreenShot() {
    if (isWindows()) {
        var exePath = path.dirname(remote.process.execPath);
        var screenShotExePath = path.join(exePath, "capture/NiuniuCapture.exe");
        if(!fs.existsSync(screenShotExePath))
        {
            console.log("not exist, use current path");
            screenShotExePath = path.join(__dirname, "capture/NiuniuCapture.exe");
        }
        console.log(screenShotExePath);
        child.execFile(screenShotExePath, function (err, data) {
            if (err == null) {  //完成截图
                finishShot(err.code);
            }
            else {
                finishShot(err.code);
            //   console.error(err);
            }
        });
    }
}

function finishShot(code) {
    if (code == 1) {
        let nativeImage = clipboard.readImage('selection');
        if (nativeImage.getSize().width > 0) //粘贴图片
        {
            var image = clipboard.readImage();
            let nativeImageSrc = image.toDataURL();
            let html = "<img  src='" + nativeImageSrc + "' alt='' />";
            $("#snapShotContent").html(html);
        }
    }
    else if (code == 2) {//取消截图
    }
    else if (code == 3) {//保存截图
    }
}
function isWindows() {
    var os = require("os");
    return os.platform() == "win32";
}
