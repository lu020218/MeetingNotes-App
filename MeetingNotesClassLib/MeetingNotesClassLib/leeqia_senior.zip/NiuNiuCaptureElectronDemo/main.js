﻿// 载入electron模块
const electron = require("electron");
const {dialog } = require('electron');
const ipc = electron.ipcMain;
// 创建应用程序对象
const app = electron.app;
// 创建一个浏览器窗口，主要用来加载HTML页面
const BrowserWindow = electron.BrowserWindow;
const log = require('electron-log')
log.transports.file.level = 'info'
log.info(`App v${app.getVersion()} starting...`)


const { autoUpdater } = require("electron-updater")
autoUpdater.logger = log
// 声明一个BrowserWindow对象实例
let mainWindow;

//定义一个创建浏览器窗口的方法
function createWindow() {
    // 创建一个浏览器窗口对象，并指定窗口的大小
    mainWindow = new BrowserWindow({
        width: 1200,
        height: 750,
        icon: "app.ico",
		webPreferences: {
            nodeIntegration: true
        }
    });
    // 通过浏览器窗口对象加载index.html文件，同时也是可以加载一个互联网地址的
    mainWindow.loadURL('file://' + __dirname + '/index.html#/');
    // 同时也可以简化成：mainWindow.loadURL('./index.html');

    // 打开开发工具
    mainWindow.openDevTools();
    //  mainWindow.maximize();
    // 监听浏览器窗口对象是否关闭，关闭之后直接将mainWindow指向空引用，也就是回收对象内存空间
    mainWindow.on("closed", function () {
        mainWindow = null;
    });
}

// 监听应用程序对象是否初始化完成，初始化完成之后即可创建浏览器窗口
app.on('ready', () => {
    createWindow();
    checkForUpdates()
})
// 监听应用程序对象中的所有浏览器窗口对象是否全部被关闭，如果全部被关闭，则退出整个应用程序。该
app.on("window-all-closed", function () {
    // 判断当前操作系统是否是window系统，因为这个事件只作用在window系统中
    if (process.platform != "darwin") {
        // 退出整个应用程序
        app.quit();
    }
});

// 监听应用程序图标被通过点或者没有任何浏览器窗口显示在桌面上，那我们应该重新创建并打开浏览器窗口，避免Mac OS X系统回收或者销毁浏览器窗口
app.on("activate", function () {
    if (mainWindow === null) {
        createWindow();
    }
});


function checkForUpdates() {
    log.info('Set up event listeners...')
    autoUpdater.on('checking-for-update', () => {
      log.info('Checking for update...')
    })
    autoUpdater.on('update-available', (info) => {
      log.info('Update available.')
    })
    autoUpdater.on('update-not-available', (info) => {
      log.info('Update not available.')
    })
    autoUpdater.on('error', (err) => {
      log.info('Error in auto-updater.' + err)
    })
    autoUpdater.on('download-progress', (progressObj) => {
      let msg = "Download speed: " + progressObj.bytesPerSecond
      msg = msg + ' - Downloaded ' + progressObj.percent + '%'
      msg = msg + ' (' + progressObj.transferred + "/" + progressObj.total + ')'
      log.info(msg)
    })
    autoUpdater.on('update-downloaded', (info) => {
      log.info('Update downloaded.')
  
      // The update will automatically be installed the next time the
      // app launches. If you want to, you can force the installation
      // now:
      const dialogOpts = {
        type: 'info',
        buttons: ['重启', '稍后'],
        title: '版本升级',
        message: "有新版本可用了",
        detail: `新版本 (${info.version}) 已经下载，重启并更新.`
      }
  
      dialog.showMessageBox(dialogOpts).then((returnValue) => {
        if (returnValue.response === 0) autoUpdater.quitAndInstall(false, true)
      })
    })
    log.info('checkForUpdates() -- begin')
    try {
      autoUpdater.checkForUpdates()
      autoUpdater.autoInstallOnAppQuit = false
    } catch (error) {
      log.info(error)
    }
    log.info('checkForUpdates() -- end')
  }
