#!/usr/bin/python3
# coding=utf8
from tkinter import *
from tkinter.ttk import *
import util
import os
import json
import fileinput
import tkinter.messagebox
from shutil import copyfile
import tkinter.font as tkFont
from tkinter import font

"""
要使用此工具，需要执行安装： pip install tk
"""


# 自动隐藏滚动条
def scrollbar_autohide(bar,widget):
    def show():
        bar.lift(widget)
    def hide():
        bar.lower(widget)
    hide()
    widget.bind("<Enter>", lambda e: show())
    bar.bind("<Enter>", lambda e: show())
    widget.bind("<Leave>", lambda e: hide())
    bar.bind("<Leave>", lambda e: hide())
    
class WinGUI(Tk):
    def __init__(self):
        super().__init__()
        self.__win()

        # 用于保存控件名对应的控件对象，对象值
        self.controls = {}      # name / value
        self.frame_config = Frame_lg5sxncy(self)
        self.frame_control = Frame_lg5t2ggg(self)
        self.save_config = self.__save_config()
        self.generate_config = self.__generate_config()
        self.open_duidesigner = self.__open_duidesigner()
        self.run_package = self.__run_package()
        self.frame_macro = Frame_lg5vsexu(self)
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        # 是否正在变更配置名的下拉框，如果是，则不进行change事件处理
        self.is_processing = False

    def __win(self):
        # self.option_add("*Font", "'Microsoft YaHei' 10")
        font.nametofont("TkDefaultFont").configure(family="Microsoft YaHei", size=8)
        self.title("nsNiuniuSkin Installation Package Configuration and Packaging Assistant")
        # 设置窗口大小、居中
        width = 950
        height = 620
        screenwidth = self.winfo_screenwidth()
        screenheight = self.winfo_screenheight()
        geometry = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        self.geometry(geometry)
        self.resizable(width=False, height=False)

    def __save_config(self):
        btn = Button(self, text="Save Config And Scripts", takefocus=False,)
        btn.place(x=0, y=580, width=157, height=24)
        return btn

    def __generate_config(self):
        btn = Button(self, text="Generate Package", takefocus=False,)
        btn.place(x=177, y=580, width=145, height=24)
        return btn

    def __open_duidesigner(self):
        btn = Button(self, text="Open UI Designer", takefocus=False,)
        btn.place(x=510, y=580, width=145, height=24)
        return btn

    def __run_package(self):
        btn = Button(self, text="Run Package")
        btn.place(x=340, y=580, width=150, height=24)
        return btn

class Frame_lg5sxncy(LabelFrame):
    def __init__(self,parent):
        super().__init__(parent)
        self.controls = parent.controls
        self.__frame()
        self.label_lg5sz51b()
        self.combo_config = self.__combo_config()
        self.label_lg5t0k5f()
        self.config_name = self.__config_name()
        self.new_config = self.__new_config()
        self.copy_config = self.__copy_config()
        self.modify_config = self.__modify_config()
        self.delete_config = self.__delete_config()
    def __frame(self):
        self.configure(text="Config manage")
        self.place(x=10, y=10, width=928, height=55)

    def label_lg5sz51b(self):
        label = Label(self,text="Configs",anchor="e", )
        label.place(x=0, y=0, width=82, height=24)
        return label

    def __combo_config(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("")
        cb.place(x=100, y=0, width=111, height=24)
        self.controls["combo_config"] = [cb, ""]
        return cb

    def label_lg5t0k5f(self):
        label = Label(self,text="Config Name",anchor="e", )
        label.place(x=220, y=0, width=84, height=24)
        return label

    def __config_name(self):
        ipt = Entry(self)
        ipt.place(x=310, y=0, width=125, height=24)
        self.controls["config_name"] = [ipt, ""]
        return ipt

    def __new_config(self):
        btn = Button(self, text="Create Config", takefocus=False,)
        btn.place(x=460, y=0, width=102, height=28)
        return btn

    def __copy_config(self):
        btn = Button(self, text="Copy Config", takefocus=False,)
        btn.place(x=580, y=0, width=92, height=28)
        return btn
        
    def __modify_config(self):
        btn = Button(self, text="Modify Config Name", takefocus=False,)
        btn.place(x=688, y=0, width=129, height=28)
        return btn

    def __delete_config(self):
        btn = Button(self, text="Delete Config", takefocus=False,)
        btn.place(x=828, y=0, width=86, height=28)
        return btn

class Frame_lg5t2ggg(LabelFrame):
    def __init__(self, parent):
        super().__init__(parent)
        self.controls = parent.controls
        self.__frame()
        self.label_lg5t3fje()
        self.project_name = self.__project_name()
        self.label_aaaaaa()
        self.label_lg5t6rh0()
        self.label_lg5t6u3z()
        self.label_lg5t6x2r()
        self.local_dir = self.__local_dir()
        self.label_lg5t898o()
        self.label_lg5t8lrt()
        self.label_lg5t8oqc()
        self.label_lg5t8rg7()
        self.src_dir = self.__src_dir()
        self.uninst_name = self.__uninst_name()
        self.electron_project_path = self.__electron_project_path()
        self.combo_package_mode = self.__combo_package_mode()
        self.combo_sign = self.__combo_sign()
        self.combo_electron = self.__combo_electron()
        self.combo_latest = self.__combo_latest()
        self.label_lg5vob16()
        self.btn_load_from_nsi = self.__load_from_nsi()

    def __frame(self):
        self.configure(text="Control Pamras")
        self.place(x=10, y=70, width=927, height=148)

    def __load_from_nsi(self):
        btn = Button(self, text="Load params from NSI", takefocus=False,)
        btn.place(x=240, y=10, width=138, height=24)
        return btn

    def label_lg5t3fje(self):
        label = Label(self,text="Project Name",anchor="e", )
        label.place(x=0, y=10, width=126, height=23)
        return label

    def __project_name(self):
        ipt = Entry(self)
        ipt.place(x=140, y=10, width=91, height=24)
        self.controls["project_name"] = [ipt, ""]
        return ipt

    def label_aaaaaa(self):
        label = Label(self,text="Local Director Name",anchor="e", )
        label.place(x=0, y=50, width=128, height=24)
        return label

    def label_lg5t6rh0(self):
        label = Label(self,text="Add Signature",anchor="e", )
        label.place(x=640, y=10, width=114, height=24)
        return label

    def label_lg5t6u3z(self):
        label = Label(self,text="Packge for Electron",anchor="e", )
        label.place(x=0, y=90, width=128, height=24)
        return label

    def label_lg5t6x2r(self):
        label = Label(self,text="Generate latest.xml",anchor="e", )
        label.place(x=640, y=90, width=114, height=24)
        return label

    def __local_dir(self):
        ipt = Entry(self)
        ipt.place(x=140, y=50, width=150, height=24)
        self.controls["local_dir"] = [ipt, ""]
        return ipt

    def label_lg5t898o(self):
        label = Label(self,text="Package Mode",anchor="e", )
        label.place(x=384, y=10, width=89, height=24)
        return label

    def label_lg5t8lrt(self):
        label = Label(self,text="Origin Director Path",anchor="e", )
        label.place(x=310, y=50, width=167, height=24)
        return label

    def label_lg5t8oqc(self):
        label = Label(self,text="Uninstall File Name",anchor="e", )
        # label.place(x=610, y=50, width=154, height=24)
        label.place(x=640, y=50, width=114, height=24)
        return label

    def label_lg5t8rg7(self):
        label = Label(self,text="Electron Project Path",anchor="e", )
        label.place(x=300, y=90, width=171, height=24)
        return label

    def __src_dir(self):
        ipt = Entry(self)
        ipt.place(x=480, y=50, width=150, height=24)
        self.controls["src_dir"] = [ipt, ""]
        return ipt

    def __uninst_name(self):
        ipt = Entry(self)
        ipt.place(x=770, y=50, width=150, height=24)
        self.controls["uninst_name"] = [ipt, ""]
        return ipt

    def __electron_project_path(self):
        ipt = Entry(self)
        ipt.place(x=480, y=90, width=150, height=24)
        self.controls["electron_project_path"] = [ipt, ""]
        return ipt

    def __combo_package_mode(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("7z","nozip","online")
        cb.set("nozip")
        cb.place(x=480, y=10, width=150, height=24)
        self.controls["combo_package_mode"] = [cb, "nozip"]
        return cb

    def __combo_sign(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("0","1")
        cb.set("1")
        cb.place(x=770, y=10, width=150, height=24)
        self.controls["combo_sign"] = [cb, "1"]
        return cb

    def __combo_electron(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("0","1")
        cb.set(0)
        cb.place(x=140, y=90, width=150, height=24)
        self.controls["combo_electron"] = [cb, "0"]
        return cb

    def __combo_latest(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("0","1")
        cb.set("0")
        cb.place(x=770, y=90, width=150, height=24)
        self.controls["combo_latest"] = [cb, "0"]
        return cb

    def label_lg5vob16(self):
        label = Label(self,text="Local Director Name",anchor="e", )
        label.place(x=0, y=50, width=128, height=24)
        return label

class Frame_lg5vsexu(LabelFrame):
    def __init__(self,parent):
        super().__init__(parent)
        self.controls = parent.controls
        self.__frame()
        self.tk_label_lg5t3fje = self.label_lg5t3fje()
        self.product_name = self.__product_name()
        self.label_lg5t6rh0()
        self.label_lg5t6u3z()
        self.label_lg5t6x2r()
        self.output_name = self.__output_name()
        self.label_lg5t898o()
        self.label_lg5t8lrt()
        self.label_lg5t8oqc()
        self.label_lg5t8rg7()
        self.product_version = self.__product_version()
        self.append_path = self.__append_path()
        self.install_location = self.__install_location()
        self.combo_shortcut = self.__combo_shortcut()
        self.label_lg5vob16()
        self.product_name_en = self.__product_name_en()
        self.exe_name = self.__exe_name()
        self.install_guid = self.__install_guid()
        self.label_lg5w3h97()
        self.default_setup_path = self.__default_setup_path()
        self.label_lg5wbrn5()
        self.product_legal = self.__product_legal()
        self.label_bbb()
        self.publisher_info = self.__publisher_info()
        self.combo_autorun = self.__combo_autorun()
        self.label_lg5wffun()
        self.label_lg5wg46f()
        self.combo_execute_level = self.__combo_execute_level()
        self.label_lg5wh7bs()
        self.combo_user = self.__combo_user()
        self.label_lg5wivh1()
        self.online_download_baseurl = self.__online_download_baseurl()
        self.tk_text_lg5wph98 = self.__tk_text_lg5wph98()

    def __frame(self):
        self.configure(text="params")
        self.place(x=10, y=220, width=927, height=344)

    def label_lg5t3fje(self):
        label = Label(self,text="Product Name",anchor="e", )
        label.place(x=0, y=10, width=133, height=23)
        return label

    def __product_name(self):
        ipt = Entry(self)
        ipt.place(x=140, y=10, width=150, height=24)
        self.controls["product_name"] = [ipt, ""]
        return ipt

    def label_lg5t6rh0(self):
        label = Label(self,text="Main Exe Name",anchor="e", )
        label.place(x=307, y=50, width=168, height=24)
        return label

    def label_lg5t6u3z(self):
        label = Label(self,text="Install Registry Identifier",anchor="e", )
        label.place(x=0, y=90, width=129, height=24)
        return label

    def label_lg5t6x2r(self):
        label = Label(self,text="Default Check Shortcut",anchor="e", )
        label.place(x=0, y=250, width=135, height=24)
        return label

    def __output_name(self):
        ipt = Entry(self)
        ipt.place(x=770, y=10, width=150, height=24)
        self.controls["output_name"] = [ipt, ""]
        return ipt

    def label_lg5t898o(self):
        label = Label(self,text="Product English Name",anchor="e", )
        label.place(x=303, y=10, width=168, height=24)
        return label

    def label_lg5t8lrt(self):
        label = Label(self,text="Product Version",anchor="e", )
        label.place(x=0, y=50, width=132, height=24)
        return label

    def label_lg5t8oqc(self):
        label = Label(self,text="Append Directory Name",anchor="e", )
        label.place(x=610, y=50, width=158, height=24)
        return label

    def label_lg5t8rg7(self):
        label = Label(self,text="Install Path Registry Key",anchor="e")
        label.place(x=306, y=90, width=166, height=24)
        return label

    def __product_version(self):
        ipt = Entry(self)
        ipt.place(x=140, y=50, width=150, height=24)
        self.controls["product_version"] = [ipt, ""]
        return ipt

    def __append_path(self):
        ipt = Entry(self)
        ipt.place(x=770, y=50, width=150, height=24)
        self.controls["append_path"] = [ipt, ""]
        return ipt

    def __install_location(self):
        ipt = Entry(self)
        ipt.place(x=480, y=90, width=150, height=24)
        self.controls["install_location"] = [ipt, ""]
        return ipt

    def __combo_shortcut(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("0","1")
        cb.set("0")
        cb.place(x=140, y=250, width=150, height=24)
        self.controls["combo_shortcut"] = [cb, "0"]
        return cb

    def label_lg5vob16(self):
        label = Label(self,text="Package Output Name",anchor="e", )
        label.place(x=610, y=10, width=158, height=24)
        return label

    def __product_name_en(self):
        ipt = Entry(self)
        ipt.place(x=480, y=10, width=150, height=24)
        self.controls["product_name_en"] = [ipt, ""]
        return ipt

    def __exe_name(self):
        ipt = Entry(self)
        ipt.place(x=480, y=50, width=150, height=24)
        self.controls["exe_name"] = [ipt, ""]
        return ipt

    def __install_guid(self):
        ipt = Entry(self)
        ipt.place(x=140, y=90, width=150, height=24)
        self.controls["install_guid"] = [ipt, ""]
        return ipt

    def label_lg5w3h97(self):
        label = Label(self,text="Default Setup Path",anchor="e")
        label.place(x=0, y=130, width=127, height=24)
        return label

    def __default_setup_path(self):
        ipt = Entry(self)
        ipt.place(x=140, y=130, width=491, height=24)
        self.controls["default_setup_path"] = [ipt, ""]
        return ipt

    def label_lg5wbrn5(self):
        label = Label(self,text="Product Legal",anchor="e")
        label.place(x=0, y=210, width=132, height=24)
        return label

    def __product_legal(self):
        ipt = Entry(self)
        ipt.place(x=140, y=210, width=150, height=24)
        self.controls["product_legal"] = [ipt, ""]
        return ipt

    def label_bbb(self):
        label = Label(self,text="Publisher Info",anchor="e")
        label.place(x=300, y=210, width=176, height=24)
        return label

    def __publisher_info(self):
        ipt = Entry(self)
        ipt.place(x=480, y=210, width=150, height=24)
        self.controls["publisher_info"] = [ipt, ""]
        return ipt

    def __combo_autorun(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("0","1")
        cb.set("0")
        cb.place(x=480, y=250, width=150, height=24)
        self.controls["combo_autorun"] = [cb, "0"]
        return cb

    def label_lg5wffun(self):
        label = Label(self,text="Default Check Autorun",anchor="e", )
        label.place(x=300, y=250, width=174, height=24)
        return label

    def label_lg5wg46f(self):
        label = Label(self,text="Execute Level",anchor="e", )
        label.place(x=0, y=290, width=129, height=24)
        return label

    def __combo_execute_level(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("admin","user")
        cb.set("admin")
        cb.place(x=140, y=290, width=150, height=24)
        self.controls["combo_execute_level"] = [cb, "admin"]
        return cb

    def label_lg5wh7bs(self):
        label = Label(self,text="Install For Current/All User",anchor="e", )
        label.place(x=300, y=290, width=177, height=24)
        return label

    def __combo_user(self):
        cb = Combobox(self, state="readonly")
        cb['values'] = ("all","current")
        cb.set("all")        
        cb.place(x=480, y=290, width=150, height=24)
        self.controls["combo_user"] = [cb, "all"]
        return cb

    def label_lg5wivh1(self):
        label = Label(self,text="Upgrade Download Url",anchor="e", )
        label.place(x=0, y=170, width=136, height=24)
        return label

    def __online_download_baseurl(self):
        ipt = Entry(self, )
        ipt.place(x=140, y=170, width=489, height=24)
        self.controls["online_download_baseurl"] = [ipt, ""]
        return ipt

    def __tk_text_lg5wph98(self):
        val = "This tool helps you with the following tasks:\n"
        val += "1. Understand the configuration options for nsNiuniuSkin packaging through a visual interface\n"
        val += "2. Quickly configure packaging parameters for different projects, with a one-click switch\n"
        val += "3. Generate install packages and add code signatures with a single click\n"
        val += "4. One-click packaging for Electron programs, generating latest.yml\n"
        val += "5. Generate command-line packaging parameters to assist in automated integration\n"
        val += "6. Open nsNiuniuSkin preview and debugger with a click, doubling UI configuration efficiency\n"

        text = Text(self, state="normal")
        text.insert(INSERT, val)
        text.config(state=DISABLED)
        text.place(x=640, y=90, width=286, height=282)
        
        return text

class Win(WinGUI):
    def __init__(self):
        super().__init__()
        self.__event_bind()
        self.defaultvals = {
            "combo_user":           "all",
            "combo_execute_level":  "admin",
            "combo_package_mode":   "nozip",
            "combo_electron":       "0",
            "combo_latest":         "0",
            "combo_sign":           "0",
            "combo_autorun":        "0",
            "combo_shortcut":       "0",
            "local_dir":       "FilesToInstall",
            "uninst_name": "uninst.exe"
        }
        self.load_configs()
        self.on_config_change(None)
            
    def __event_bind(self):
        self.frame_config.combo_config.bind('<<ComboboxSelected>>',self.on_config_change)
        self.frame_config.new_config.config(command=self.on_new_config)
        self.frame_config.copy_config.config(command=self.on_copy_config)
        self.frame_config.modify_config.config(command=self.on_modify_config)
        self.frame_config.delete_config.config(command=self.on_delete_config)
        self.save_config.config(command=self.on_save)
        self.generate_config.config(command=self.on_generate)
        self.open_duidesigner.config(command=self.on_open_duidesigner)
        self.run_package.config(command=self.on_run_package)
        self.frame_control.btn_load_from_nsi.config(command= self.on_load_from_nsi)

    # 加载所有配置项
    def load_configs(self):        
        self.is_processing = True
        list_configs = []
        # 遍历json文件，进行处理
        dir_path = self.get_config_path("", True)
        files = os.listdir(dir_path)
        for file in files:
            file_path = os.path.join(dir_path, file)
            file_name = file
            if os.path.isfile(file_path):
                if file_name == "real_output_name.json":
                    continue
                if file_name.find(".json") > 0:            
                    file_name = file_name.replace(".json", "")
                    print(file_name)
                    list_configs.append(file_name)
        
        self.controls["combo_config"][0]["value"] = list_configs    
        self.is_processing = False
        # 默认选中第一个
        if len(list_configs) > 0:
            self.controls["combo_config"][0].set(list_configs[0])

    def get_config_path(self, config_name:str, is_dir:bool) -> str:
        if is_dir:
            return f"{self.base_dir}"
        return f"{self.base_dir}\\{config_name}.json"
    
    def func_generate_config(self) -> str:
        tmp = {}
        for key in self.controls.keys():
            val = self.controls[key][1]
            if len(val) > 0:
                tmp[key] = val
        ret = json.dumps(tmp, indent=4, ensure_ascii=False)
        print(ret)
        return ret

    def get_all_values(self):
        for key in self.controls.keys():
            if key == "combo_config" or key == "config_name":
                continue
            self.controls[key][1] = self.controls[key][0].get()

    def set_all_values(self, dic_filters):
        for key in self.controls.keys():
            if key == "combo_config" or key == "config_name":
                continue
            if key.find("combo_") == 0:
                self.controls[key][0].set(self.controls[key][1])
            else:
                self.controls[key][0].delete(0, END)
                self.controls[key][0].insert(0, self.controls[key][1])
        

    # 从配置文件读取配置 
    def read_config_from_file(self, file_path:str):
        with open(file_path, "r", encoding='utf-8') as load_f:
            load_dict = json.load(load_f)
            for key in self.controls.keys():
                if key == "combo_config" or key == "config_name":
                    continue
                if key in load_dict:
                    self.controls[key][1] = load_dict[key]
                else:
                    if key in self.defaultvals:
                        self.controls[key][1] = self.defaultvals[key]
                    else:    
                        self.controls[key][1] = ""

    # 解析NSI文件中的配置
    def read_line_config_from_nsi(self, line:str, key:str, filter:str, dest_key:str, type: int):
        if line.find(key) < 0:
            return False
        if len(filter) > 0 and line.find(filter) > 0:
            return False
        print(key)
        if type == 1:
            pos1 = line.find('"')
            pos2 = line.find('"', pos1 + 1)
            
            val = line[pos1+1 : pos2]
            print(dest_key, pos1, pos2, val)
            self.controls[dest_key][1] = val
        else:
            line = line.replace(" ", "")
            line = line.replace("   ", "")
            if line.find(f"{key}1") > 0:
                self.controls[dest_key][1] = "1"
            else:
                self.controls[dest_key][1] = "0"
        return True

    # 从nsi文件中读取配置
    def read_config_from_nsi(self, file_path:str):
        self.controls["product_name"][1] = "AAAA"
        file_object2 = open(file_path, 'r', encoding="utf16")
        try:
            lines = file_object2.readlines()
            for line in lines:
                self.read_line_config_from_nsi(line, "PRODUCT_NAME", "PRODUCT_NAME_EN", "product_name", 1)
                self.read_line_config_from_nsi(line, "PRODUCT_NAME_EN", "", "product_name_en", 1)
                self.read_line_config_from_nsi(line, "PRODUCT_PATHNAME", "", "install_guid", 1)
                self.read_line_config_from_nsi(line, "INSTALL_APPEND_PATH", "INSTALL_DEFALT_SETUPPATH", "append_path", 1)
                self.read_line_config_from_nsi(line, "INSTALL_DEFALT_SETUPPATH", "", "default_setup_path", 1)
                self.read_line_config_from_nsi(line, "EXE_NAME", "", "exe_name", 1)
                self.read_line_config_from_nsi(line, "PRODUCT_VERSION", "", "product_version", 1)
                self.read_line_config_from_nsi(line, "PRODUCT_PUBLISHER", "", "publisher_info", 1)
                self.read_line_config_from_nsi(line, "PRODUCT_LEGAL", "", "product_legal", 1)
                self.read_line_config_from_nsi(line, "INSTALL_MODE_ALL_USERS", "INSTALL_EXECUTION_LEVEL", "combo_user", 1)
                self.read_line_config_from_nsi(line, "INSTALL_EXECUTION_LEVEL", "", "combo_execute_level", 1)
                self.read_line_config_from_nsi(line, "INSTALL_OUTPUT_NAME", "", "output_name", 1)
                self.read_line_config_from_nsi(line, "INSTALL_LOCATION_KEY", "", "install_location", 1)
                self.read_line_config_from_nsi(line, "INSTALL_DOWNLOAD_BASEURL", "", "online_download_baseurl", 1)
                self.read_line_config_from_nsi(line, "INSTALL_DEFAULT_AUTORUN", "", "combo_autorun", 0)
                self.read_line_config_from_nsi(line, "INSTALL_DEFAULT_SHOTCUT", "", "combo_shortcut", 0)
                if line.find("INSTALL_7Z_PATH") > 0:
                    break
        finally:
            file_object2.close()

    def on_generate(self):
        # 先保存配置
        ret = self.on_save()
        if not ret:
            warn("Generate config failed")
            return
        
        ret, cmd = self.func_generate_tun_config(False)
        if not ret:
            warn("Generate config failed")
            return
        # 再生成一个调用的打包脚本        
        ret = util.run_cmd_wait_ret(cmd, True)
        if ret:
            self.warn("Congratulations, packaging successful!")
        else:
            self.warn("Package failed")    
    
    def on_run_package(self):
        output_name = self.controls["output_name"][0].get()
        # 读取实际的安装包名(Electron打包下，会在内部变更安装包名称)
        real_output_name = ""
        file_path = f"{self.base_dir}\\real_output_name.json"
        with open(file_path, "r", encoding='utf-8') as load_f:
            load_dict = json.load(load_f)
            real_output_name = load_dict["output_name"]
        if len(real_output_name) > 0 and real_output_name != output_name:
            self.warn(f"If the actual packaged installer name differs from the interface configuration, the name generated during actual packaging will be used: {real_output_name}")
        
        output_path = f"{self.base_dir}\Output\{real_output_name}"
        os.system(output_path)

    def on_open_duidesigner(self):
        # 根据当前的配置项目名称，得到项目路径，复制后打开网页
        # 如果能够自动输入地址更好
        str_project_name = self.controls["project_name"][0].get()
        if len(str_project_name) > 0:
            # 将skin路径复制到剪贴板，方便在线调试器中打开 
            skin_path = f"{self.base_dir}\\SetupScripts\\{str_project_name}\\skin"
            r = Tk()
            r.withdraw()
            r.clipboard_clear()
            r.clipboard_append(skin_path)
            r.update()
            r.destroy()
        os.system("start \"\" http://ggniu.com/uidesigner/duidesigner.htm")
        
    def on_config_change(self, evt):
        if self.is_processing:
            return
        config_name = self.controls["combo_config"][0].get()
        if len(config_name) <1:
            return
        config_path = self.get_config_path(config_name, False)
        if not os.path.exists(config_path):
            return
        self.read_config_from_file(config_path)
        dic_filters = {"combo_config": 1, "config_name":1}
        self.set_all_values(dic_filters)
    
    def warn(self, msg:str):
        tkinter.messagebox.showwarning(title="Notice", message=msg)

    def on_modify_config(self):
        config_name = self.controls["config_name"][0].get()
        if len(config_name) < 1:
            self.warn("Config name is empty")
            return
        old_config_name = self.controls["combo_config"][0].get()
        if len(config_name) < 1:
            self.warn("Old config name is empty")
            return
        if old_config_name == config_name:
            return
        
        config_path = self.get_config_path(config_name, False)
        if os.path.exists(config_path):
            self.warn("Config name already exists")
            return
        

        old_conf_path = self.get_config_path(old_config_name, False)
        os.rename(old_conf_path, config_path)
        self.load_configs()
        self.controls["combo_config"][0].set(config_name)
        self.on_config_change(None)

    def on_delete_config(self):
        old_config_name = self.controls["combo_config"][0].get()
        old_conf_path = self.get_config_path(old_config_name, False)
        util.remove_file(old_conf_path)
        self.load_configs()
        self.on_config_change(None)

    def on_copy_config(self):
        config_name = self.controls["config_name"][0].get()
        if len(config_name) < 1:
            self.warn("Config name is empty")
            return
        old_config_name = self.controls["combo_config"][0].get()
        if len(config_name) < 1:
            self.warn("Old config name is empty")
            return
        config_path = self.get_config_path(config_name, False)
        if os.path.exists(config_path):
            self.warn("Config name already exists")
            return
        old_conf_path = self.get_config_path(old_config_name, False)
        copyfile(old_conf_path, config_path)
        self.load_configs()        
        self.controls["combo_config"][0].set(config_name)
        self.on_config_change(None)

    def on_new_config(self):
        config_name = self.controls["config_name"][0].get()
        if len(config_name) < 1:
            self.warn("Config name is empty")
            return
        config_path = self.get_config_path(config_name, False)
        if os.path.exists(config_path):
            self.warn("Config name already exists")
            return
        util.write_content(config_path, "{}")
        #重新设置 combo_config 的值，并且选中他，触发change事件
        self.load_configs()        
        self.controls["combo_config"][0].set(config_name)
        self.on_config_change(None)

    def on_load_from_nsi(self):
        str_project_name = self.controls["project_name"][0].get()
        if len(str_project_name) < 1:
            return
        self.controls["project_name"][1] = str_project_name
        nsi_path = f"{self.base_dir}\\SetupScripts\\{str_project_name}\\soft_setup.nsi"
        self.read_config_from_nsi(nsi_path)
        dic_filters = {"combo_config": 1, "config_name":1}
        self.set_all_values(dic_filters)

    def check_config(self) -> tuple:
        build_for_electron = self.controls["combo_electron"][1]
        if build_for_electron == "0":
            output_name = self.controls["output_name"][1]
            if len(output_name) < 1:
                return False, "Package name is empty"
        else:
            install_location = self.controls["install_location"][1]
            if install_location != "InstallLocation":
                return False, "Electron packaging, the key for the installation path in the registry should be 'InstallLocation'."
        return True, ""
    
    def on_save(self):
        return self.func_generate_tun_config(True)

    def func_generate_tun_config(self, gen_bat:bool) -> tuple:
        config_name = self.controls["combo_config"][0].get()
        if len(config_name) < 1:
            self.warn("Old config name is empty")
            return False, ""
        # 把所有控件的值赋值到dict中
        self.get_all_values()
        ret, err = self.check_config()
        if not ret:
            self.warn(err)
            return False, ""
        
        config_path = self.get_config_path(config_name, False)
        config_content = self.func_generate_config()
        util.write_content(config_path, config_content)

        dic_map = {
            #---------------控制参数---------------------
            "project_name": ["--project_name", 1],
            "combo_package_mode": ["--package_mode", 2],
            "combo_sign":   ["--need_sign", 0],
            "combo_electron": ["--build_for_electron", 0],
            "electron_project_path": ["--electron_build_path", 1],
            "combo_latest": ["--generate_latest_file", 0],
            "local_dir":    ["--files_toinstall_name", 1],
            "uninst_name": ["--uninst_file_name", 1],
            "src_dir":      ["--src_files_dir", 1],
            #--------------------宏定义---------------------
            "product_name": ["--PRODUCT_NAME", 1],
            "product_name_en": ["--PRODUCT_NAME_EN", 1],
            "output_name": ["--INSTALL_OUTPUT_NAME", 1],
            "product_version": ["--PRODUCT_VERSION", 1],
            "exe_name": ["--EXE_NAME", 1],
            "install_location": ["--INSTALL_LOCATION_KEY", 1],
            "append_path": ["--INSTALL_APPEND_PATH", 1],
            "install_guid": ["--PRODUCT_PATHNAME", 1],
            "default_setup_path": ["--INSTALL_DEFALT_SETUPPATH", 1],
            "combo_shortcut": ["--INSTALL_DEFAULT_SHOTCUT", 2],
            "combo_autorun": ["--INSTALL_DEFAULT_AUTORUN", 2],
            "combo_execute_level": ["--INSTALL_EXECUTION_LEVEL", 1],
            "combo_user": ["--INSTALL_MODE_ALL_USERS", 1],
            "online_download_baseurl": ["--INSTALL_DOWNLOAD_BASEURL", 1],
            "product_legal": ["--PRODUCT_LEGAL", 1],
            "publisher_info": ["--PRODUCT_PUBLISHER", 1],
        }
        # 根据配置，生成bat，其中调用python命令
        content = "python package.py"
        if gen_bat:
            content = "chcp 65001\n" + content
        params = ""
        for key in dic_map.keys():
            if key not in self.controls:
                continue
            
            dest_key = dic_map[key][0]
            val = self.controls[key][1]
            if len(val) < 1:
                continue
            flag = dic_map[key][1]
            if flag == 1:
                params += f' {dest_key}="{val}"'
            elif flag == 0:
                if val == "1":
                    val = "True"
                else:
                    val = "False"
                params += f' {dest_key}={val}'
            else:
                if key == "combo_package_mode":
                    if val == "7z":
                        val = 1
                    elif val == "nozip":
                        val = 2
                    else:
                        val = 3
                params += f' {dest_key}={val}'
        params += " --TEST_SLEEP=0"
        content += params

        project_name = self.controls["project_name"][1]
        package_mode = self.controls["combo_package_mode"][1]
        save_path = f"{self.base_dir}\\generate_{project_name}_{package_mode}.bat"
        if gen_bat:
            content += "\nchcp 936\n"            
            util.write_content(save_path, content)
        
        cmd_content = "python ../package.py" + params
        cmd_content = cmd_content.replace("\\", "\\\\")
        cmd_content = cmd_content.replace("\"", "\\\"")
        save_path = f"{self.base_dir}\\generate_{project_name}_{package_mode}_cmdline.txt"
        if gen_bat:        
            util.write_content(save_path, cmd_content)
        return True, content
        
if __name__ == "__main__":
    # default_font = tkFont.nametofont("TkDefaultFont")
    # default_font.configure(size=12)
	# root = tk.Tk()
	# root.option_add("*Font", "Arial 12")
    win = Win()
    win.mainloop()
