"""
本代码由[Tkinter布局助手]生成
官网:https://www.pytk.net
QQ交流群:788392508
"""
from tkinter import *
from tkinter.ttk import *
class WinGUI(Tk):
    def __init__(self):
        super().__init__()
        self.__win()
        self.tk_label_frame_lg5sxncy = self.__tk_label_frame_lg5sxncy(self)
        self.tk_label_lg5sz51b = self.__tk_label_lg5sz51b( self.tk_label_frame_lg5sxncy) 
        self.tk_select_box_combo_config = self.__tk_select_box_combo_config( self.tk_label_frame_lg5sxncy) 
        self.tk_label_lg5t0k5f = self.__tk_label_lg5t0k5f( self.tk_label_frame_lg5sxncy) 
        self.tk_input_config_name = self.__tk_input_config_name( self.tk_label_frame_lg5sxncy) 
        self.tk_button_new_config = self.__tk_button_new_config( self.tk_label_frame_lg5sxncy) 
        self.tk_button_copy_config = self.__tk_button_copy_config( self.tk_label_frame_lg5sxncy) 
        self.tk_button_modify_config = self.__tk_button_modify_config( self.tk_label_frame_lg5sxncy) 
        self.tk_button_delete_config = self.__tk_button_delete_config( self.tk_label_frame_lg5sxncy) 
        self.tk_label_frame_lg5t2ggg = self.__tk_label_frame_lg5t2ggg(self)
        self.tk_label_lg5t3fje = self.__tk_label_lg5t3fje( self.tk_label_frame_lg5t2ggg) 
        self.tk_input_project_name = self.__tk_input_project_name( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_aaaaaa = self.__tk_label_aaaaaa( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_lg5t6rh0 = self.__tk_label_lg5t6rh0( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_lg5t6u3z = self.__tk_label_lg5t6u3z( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_lg5t6x2r = self.__tk_label_lg5t6x2r( self.tk_label_frame_lg5t2ggg) 
        self.tk_input_local_dir = self.__tk_input_local_dir( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_lg5t898o = self.__tk_label_lg5t898o( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_lg5t8lrt = self.__tk_label_lg5t8lrt( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_lg5t8oqc = self.__tk_label_lg5t8oqc( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_lg5t8rg7 = self.__tk_label_lg5t8rg7( self.tk_label_frame_lg5t2ggg) 
        self.tk_input_src_dir = self.__tk_input_src_dir( self.tk_label_frame_lg5t2ggg) 
        self.tk_input_uninst_name = self.__tk_input_uninst_name( self.tk_label_frame_lg5t2ggg) 
        self.tk_input_electron_project_path = self.__tk_input_electron_project_path( self.tk_label_frame_lg5t2ggg) 
        self.tk_select_box_combo_package_mode = self.__tk_select_box_combo_package_mode( self.tk_label_frame_lg5t2ggg) 
        self.tk_select_box_combo_sign = self.__tk_select_box_combo_sign( self.tk_label_frame_lg5t2ggg) 
        self.tk_select_box_combo_electron = self.__tk_select_box_combo_electron( self.tk_label_frame_lg5t2ggg) 
        self.tk_select_box_combo_latest = self.__tk_select_box_combo_latest( self.tk_label_frame_lg5t2ggg) 
        self.tk_label_lg5vob16 = self.__tk_label_lg5vob16( self.tk_label_frame_lg5t2ggg) 
        self.tk_button_load_from_nsi = self.__tk_button_load_from_nsi( self.tk_label_frame_lg5t2ggg) 
        self.tk_button_save_config = self.__tk_button_save_config(self)
        self.tk_button_generate_config = self.__tk_button_generate_config(self)
        self.tk_button_open_duidesigner = self.__tk_button_open_duidesigner(self)
        self.tk_label_frame_lg5vsexu = self.__tk_label_frame_lg5vsexu(self)
        self.tk_label_lg5t3fje = self.__tk_label_lg5t3fje( self.tk_label_frame_lg5vsexu) 
        self.tk_input_product_name = self.__tk_input_product_name( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5t6rh0 = self.__tk_label_lg5t6rh0( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5t6u3z = self.__tk_label_lg5t6u3z( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5t6x2r = self.__tk_label_lg5t6x2r( self.tk_label_frame_lg5vsexu) 
        self.tk_input_output_name = self.__tk_input_output_name( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5t898o = self.__tk_label_lg5t898o( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5t8lrt = self.__tk_label_lg5t8lrt( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5t8oqc = self.__tk_label_lg5t8oqc( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5t8rg7 = self.__tk_label_lg5t8rg7( self.tk_label_frame_lg5vsexu) 
        self.tk_input_product_version = self.__tk_input_product_version( self.tk_label_frame_lg5vsexu) 
        self.tk_input_append_path = self.__tk_input_append_path( self.tk_label_frame_lg5vsexu) 
        self.tk_input_install_location = self.__tk_input_install_location( self.tk_label_frame_lg5vsexu) 
        self.tk_select_box_combo_shortcut = self.__tk_select_box_combo_shortcut( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5vob16 = self.__tk_label_lg5vob16( self.tk_label_frame_lg5vsexu) 
        self.tk_input_product_name_en = self.__tk_input_product_name_en( self.tk_label_frame_lg5vsexu) 
        self.tk_input_exe_name = self.__tk_input_exe_name( self.tk_label_frame_lg5vsexu) 
        self.tk_input_install_guid = self.__tk_input_install_guid( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5w3h97 = self.__tk_label_lg5w3h97( self.tk_label_frame_lg5vsexu) 
        self.tk_input_default_setup_path = self.__tk_input_default_setup_path( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5wbrn5 = self.__tk_label_lg5wbrn5( self.tk_label_frame_lg5vsexu) 
        self.tk_input_product_legal = self.__tk_input_product_legal( self.tk_label_frame_lg5vsexu) 
        self.tk_label_bbb = self.__tk_label_bbb( self.tk_label_frame_lg5vsexu) 
        self.tk_input_publisher_info = self.__tk_input_publisher_info( self.tk_label_frame_lg5vsexu) 
        self.tk_select_box_combo_autorun = self.__tk_select_box_combo_autorun( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5wffun = self.__tk_label_lg5wffun( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5wg46f = self.__tk_label_lg5wg46f( self.tk_label_frame_lg5vsexu) 
        self.tk_select_box_combo_execute_level = self.__tk_select_box_combo_execute_level( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5wh7bs = self.__tk_label_lg5wh7bs( self.tk_label_frame_lg5vsexu) 
        self.tk_select_box_combo_user = self.__tk_select_box_combo_user( self.tk_label_frame_lg5vsexu) 
        self.tk_label_lg5wivh1 = self.__tk_label_lg5wivh1( self.tk_label_frame_lg5vsexu) 
        self.tk_input_online_download_baseurl = self.__tk_input_online_download_baseurl( self.tk_label_frame_lg5vsexu) 
        self.tk_text_lg5wph98 = self.__tk_text_lg5wph98( self.tk_label_frame_lg5vsexu) 
    def __win(self):
        self.title("nsNiuniuSkin Installation Package Configuration and Packaging Assistant")
        # 设置窗口大小、居中
        width = 950
        height = 620
        screenwidth = self.winfo_screenwidth()
        screenheight = self.winfo_screenheight()
        geometry = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        self.geometry(geometry)
        
        self.resizable(width=False, height=False)
        
    def scrollbar_autohide(self,vbar, hbar, widget):
        """自动隐藏滚动条"""
        def show():
            if vbar: vbar.lift(widget)
            if hbar: hbar.lift(widget)
        def hide():
            if vbar: vbar.lower(widget)
            if hbar: hbar.lower(widget)
        hide()
        widget.bind("<Enter>", lambda e: show())
        if vbar: vbar.bind("<Enter>", lambda e: show())
        if vbar: vbar.bind("<Leave>", lambda e: hide())
        if hbar: hbar.bind("<Enter>", lambda e: show())
        if hbar: hbar.bind("<Leave>", lambda e: hide())
        widget.bind("<Leave>", lambda e: hide())
    
    def v_scrollbar(self,vbar, widget, x, y, w, h, pw, ph):
        widget.configure(yscrollcommand=vbar.set)
        vbar.config(command=widget.yview)
        vbar.place(relx=(w + x) / pw, rely=y / ph, relheight=h / ph, anchor='ne')
    def h_scrollbar(self,hbar, widget, x, y, w, h, pw, ph):
        widget.configure(xscrollcommand=hbar.set)
        hbar.config(command=widget.xview)
        hbar.place(relx=x / pw, rely=(y + h) / ph, relwidth=w / pw, anchor='sw')
    def create_bar(self,master, widget,is_vbar,is_hbar, x, y, w, h, pw, ph):
        vbar, hbar = None, None
        if is_vbar:
            vbar = Scrollbar(master)
            self.v_scrollbar(vbar, widget, x, y, w, h, pw, ph)
        if is_hbar:
            hbar = Scrollbar(master, orient="horizontal")
            self.h_scrollbar(hbar, widget, x, y, w, h, pw, ph)
        self.scrollbar_autohide(vbar, hbar, widget)
    def __tk_label_frame_lg5sxncy(self,parent):
        frame = LabelFrame(parent,text="Config manage",)
        frame.place(x=10, y=10, width=928, height=55)
        return frame
    def __tk_label_lg5sz51b(self,parent):
        label = Label(parent,text="Configs",anchor="center", )
        label.place(x=0, y=0, width=82, height=24)
        return label
    def __tk_select_box_combo_config(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("")
        cb.place(x=100, y=0, width=111, height=24)
        return cb
    def __tk_label_lg5t0k5f(self,parent):
        label = Label(parent,text="Config Name",anchor="center", )
        label.place(x=220, y=0, width=84, height=24)
        return label
    def __tk_input_config_name(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=310, y=0, width=125, height=24)
        return ipt
    def __tk_button_new_config(self,parent):
        btn = Button(parent, text="Create Config", takefocus=False,)
        btn.place(x=460, y=0, width=102, height=24)
        return btn
    def __tk_button_copy_config(self,parent):
        btn = Button(parent, text="Copy Config", takefocus=False,)
        btn.place(x=580, y=0, width=92, height=24)
        return btn
    def __tk_button_modify_config(self,parent):
        btn = Button(parent, text="Modify Config Name", takefocus=False,)
        btn.place(x=688, y=0, width=129, height=24)
        return btn
    def __tk_button_delete_config(self,parent):
        btn = Button(parent, text="Delete Config", takefocus=False,)
        btn.place(x=828, y=0, width=86, height=24)
        return btn
    def __tk_label_frame_lg5t2ggg(self,parent):
        frame = LabelFrame(parent,text="Control Pamras",)
        frame.place(x=10, y=70, width=927, height=148)
        return frame
    def __tk_label_lg5t3fje(self,parent):
        label = Label(parent,text="Project Name",anchor="center", )
        label.place(x=0, y=10, width=126, height=23)
        return label
    def __tk_input_project_name(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=140, y=10, width=91, height=24)
        return ipt
    def __tk_label_aaaaaa(self,parent):
        label = Label(parent,text="Local Director Name",anchor="center", )
        label.place(x=0, y=50, width=128, height=24)
        return label
    def __tk_label_lg5t6rh0(self,parent):
        label = Label(parent,text="Add Signature",anchor="center", )
        label.place(x=640, y=10, width=157, height=24)
        return label
    def __tk_label_lg5t6u3z(self,parent):
        label = Label(parent,text="Packge for Electron",anchor="center", )
        label.place(x=0, y=90, width=128, height=24)
        return label
    def __tk_label_lg5t6x2r(self,parent):
        label = Label(parent,text="Generate latest.xml",anchor="center", )
        label.place(x=640, y=90, width=155, height=24)
        return label
    def __tk_input_local_dir(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=140, y=50, width=150, height=24)
        return ipt
    def __tk_label_lg5t898o(self,parent):
        label = Label(parent,text="Package Mode",anchor="center", )
        label.place(x=384, y=10, width=89, height=24)
        return label
    def __tk_label_lg5t8lrt(self,parent):
        label = Label(parent,text="Origin Director Path",anchor="center", )
        label.place(x=310, y=50, width=167, height=24)
        return label
    def __tk_label_lg5t8oqc(self,parent):
        label = Label(parent,text="Uninstall File Name",anchor="center", )
        label.place(x=640, y=50, width=154, height=24)
        return label
    def __tk_label_lg5t8rg7(self,parent):
        label = Label(parent,text="Electron Project Path",anchor="center", )
        label.place(x=300, y=90, width=171, height=24)
        return label
    def __tk_input_src_dir(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=480, y=50, width=150, height=24)
        return ipt
    def __tk_input_uninst_name(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=808, y=50, width=114, height=24)
        return ipt
    def __tk_input_electron_project_path(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=480, y=90, width=150, height=24)
        return ipt
    def __tk_select_box_combo_package_mode(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("7z","no7z","online")
        cb.place(x=480, y=10, width=150, height=24)
        return cb
    def __tk_select_box_combo_sign(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("0","1")
        cb.place(x=807, y=10, width=113, height=24)
        return cb
    def __tk_select_box_combo_electron(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("0","1")
        cb.place(x=140, y=90, width=150, height=24)
        return cb
    def __tk_select_box_combo_latest(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("0","1")
        cb.place(x=809, y=90, width=111, height=24)
        return cb
    def __tk_label_lg5vob16(self,parent):
        label = Label(parent,text="Local Director Name",anchor="center", )
        label.place(x=0, y=50, width=128, height=24)
        return label
    def __tk_button_load_from_nsi(self,parent):
        btn = Button(parent, text="Load params from NSI", takefocus=False,)
        btn.place(x=240, y=10, width=138, height=24)
        return btn
    def __tk_button_save_config(self,parent):
        btn = Button(parent, text="Save Config And Scripts", takefocus=False,)
        btn.place(x=40, y=580, width=157, height=24)
        return btn
    def __tk_button_generate_config(self,parent):
        btn = Button(parent, text="Generate Package", takefocus=False,)
        btn.place(x=270, y=580, width=145, height=24)
        return btn
    def __tk_button_open_duidesigner(self,parent):
        btn = Button(parent, text="Open UI Designer", takefocus=False,)
        btn.place(x=480, y=580, width=145, height=24)
        return btn
    def __tk_label_frame_lg5vsexu(self,parent):
        frame = LabelFrame(parent,text="Macro Defined Params",)
        frame.place(x=10, y=230, width=927, height=344)
        return frame
    def __tk_label_lg5t3fje(self,parent):
        label = Label(parent,text="Product Name",anchor="center", )
        label.place(x=0, y=10, width=133, height=23)
        return label
    def __tk_input_product_name(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=140, y=10, width=150, height=24)
        return ipt
    def __tk_label_lg5t6rh0(self,parent):
        label = Label(parent,text="Main Exe Name",anchor="center", )
        label.place(x=307, y=50, width=168, height=24)
        return label
    def __tk_label_lg5t6u3z(self,parent):
        label = Label(parent,text="软件安装注册表标识：",anchor="center", )
        label.place(x=0, y=90, width=129, height=24)
        return label
    def __tk_label_lg5t6x2r(self,parent):
        label = Label(parent,text="Default Check Shortcut",anchor="center", )
        label.place(x=0, y=250, width=135, height=24)
        return label
    def __tk_input_output_name(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=808, y=10, width=112, height=24)
        return ipt
    def __tk_label_lg5t898o(self,parent):
        label = Label(parent,text="Product English Name",anchor="center", )
        label.place(x=303, y=10, width=168, height=24)
        return label
    def __tk_label_lg5t8lrt(self,parent):
        label = Label(parent,text="Product Version",anchor="center", )
        label.place(x=0, y=50, width=132, height=24)
        return label
    def __tk_label_lg5t8oqc(self,parent):
        label = Label(parent,text="Append Directory Name",anchor="center", )
        label.place(x=640, y=50, width=154, height=24)
        return label
    def __tk_label_lg5t8rg7(self,parent):
        label = Label(parent,text="安装路径注册表Key：",anchor="center", )
        label.place(x=306, y=90, width=166, height=24)
        return label
    def __tk_input_product_version(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=140, y=50, width=150, height=24)
        return ipt
    def __tk_input_append_path(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=808, y=50, width=112, height=24)
        return ipt
    def __tk_input_install_location(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=480, y=90, width=150, height=24)
        return ipt
    def __tk_select_box_combo_shortcut(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("0","1")
        cb.place(x=140, y=250, width=150, height=24)
        return cb
    def __tk_label_lg5vob16(self,parent):
        label = Label(parent,text="Package Output Name",anchor="center", )
        label.place(x=640, y=10, width=158, height=24)
        return label
    def __tk_input_product_name_en(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=480, y=10, width=150, height=24)
        return ipt
    def __tk_input_exe_name(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=480, y=50, width=150, height=24)
        return ipt
    def __tk_input_install_guid(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=140, y=90, width=150, height=24)
        return ipt
    def __tk_label_lg5w3h97(self,parent):
        label = Label(parent,text="Default Setup Path",anchor="center", )
        label.place(x=0, y=130, width=127, height=24)
        return label
    def __tk_input_default_setup_path(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=140, y=130, width=491, height=24)
        return ipt
    def __tk_label_lg5wbrn5(self,parent):
        label = Label(parent,text="Product Legal",anchor="center", )
        label.place(x=0, y=210, width=132, height=24)
        return label
    def __tk_input_product_legal(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=140, y=210, width=144, height=24)
        return ipt
    def __tk_label_bbb(self,parent):
        label = Label(parent,text="Publisher Info",anchor="center", )
        label.place(x=300, y=210, width=176, height=24)
        return label
    def __tk_input_publisher_info(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=480, y=210, width=150, height=24)
        return ipt
    def __tk_select_box_combo_autorun(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("0","1")
        cb.place(x=480, y=250, width=150, height=24)
        return cb
    def __tk_label_lg5wffun(self,parent):
        label = Label(parent,text="Default Check Autorun",anchor="center", )
        label.place(x=300, y=250, width=174, height=24)
        return label
    def __tk_label_lg5wg46f(self,parent):
        label = Label(parent,text="Execute Level",anchor="center", )
        label.place(x=0, y=290, width=129, height=24)
        return label
    def __tk_select_box_combo_execute_level(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("admin","user")
        cb.place(x=140, y=290, width=150, height=24)
        return cb
    def __tk_label_lg5wh7bs(self,parent):
        label = Label(parent,text="Install For Current/All User",anchor="center", )
        label.place(x=300, y=290, width=177, height=24)
        return label
    def __tk_select_box_combo_user(self,parent):
        cb = Combobox(parent, state="readonly", )
        cb['values'] = ("all","current")
        cb.place(x=480, y=290, width=150, height=24)
        return cb
    def __tk_label_lg5wivh1(self,parent):
        label = Label(parent,text="Upgrade Download Url",anchor="center", )
        label.place(x=0, y=170, width=136, height=24)
        return label
    def __tk_input_online_download_baseurl(self,parent):
        ipt = Entry(parent, )
        ipt.place(x=140, y=170, width=489, height=24)
        return ipt
    def __tk_text_lg5wph98(self,parent):
        text = Text(parent)
        text.place(x=640, y=90, width=286, height=282)
        return text
class Win(WinGUI):
    def __init__(self):
        super().__init__()
        self.__event_bind()
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_copy_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_copy_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_copy_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_generate(self,evt):
        print("<Button>事件未处理:",evt)
    def on_open_duidesigner(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_config_change(self,evt):
        print("<<ComboboxSelected>>事件未处理:",evt)
    def on_new_config(self,evt):
        print("<Button>事件未处理:",evt)
    def on_save(self,evt):
        print("<Button>事件未处理:",evt)
    def __event_bind(self):
        self.tk_label_frame_lg5sxncy.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_frame_lg5sxncy.bind('<Button>',self.on_new_config)
        self.tk_label_frame_lg5sxncy.bind('<Button>',self.on_save)
        self.tk_label_lg5sz51b.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_lg5sz51b.bind('<Button>',self.on_new_config)
        self.tk_label_lg5sz51b.bind('<Button>',self.on_save)
        self.tk_select_box_combo_config.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_config.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_config.bind('<Button>',self.on_save)
        self.tk_label_lg5t0k5f.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_lg5t0k5f.bind('<Button>',self.on_new_config)
        self.tk_label_lg5t0k5f.bind('<Button>',self.on_save)
        self.tk_input_config_name.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_input_config_name.bind('<Button>',self.on_new_config)
        self.tk_input_config_name.bind('<Button>',self.on_save)
        self.tk_button_new_config.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_button_new_config.bind('<Button>',self.on_new_config)
        self.tk_button_new_config.bind('<Button>',self.on_save)
        self.tk_button_copy_config.bind('<Button>',self.on_copy_config)
        self.tk_button_modify_config.bind('<Button>',self.on_copy_config)
        self.tk_button_delete_config.bind('<Button>',self.on_copy_config)
        self.tk_label_frame_lg5t2ggg.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_frame_lg5t2ggg.bind('<Button>',self.on_new_config)
        self.tk_label_frame_lg5t2ggg.bind('<Button>',self.on_save)
        self.tk_label_lg5t3fje.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_lg5t3fje.bind('<Button>',self.on_new_config)
        self.tk_label_lg5t3fje.bind('<Button>',self.on_save)
        self.tk_input_project_name.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_input_project_name.bind('<Button>',self.on_new_config)
        self.tk_input_project_name.bind('<Button>',self.on_save)
        self.tk_select_box_combo_package_mode.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_package_mode.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_package_mode.bind('<Button>',self.on_save)
        self.tk_select_box_combo_sign.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_sign.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_sign.bind('<Button>',self.on_save)
        self.tk_select_box_combo_electron.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_electron.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_electron.bind('<Button>',self.on_save)
        self.tk_select_box_combo_latest.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_latest.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_latest.bind('<Button>',self.on_save)
        self.tk_label_lg5vob16.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_lg5vob16.bind('<Button>',self.on_new_config)
        self.tk_label_lg5vob16.bind('<Button>',self.on_save)
        self.tk_button_load_from_nsi.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_button_load_from_nsi.bind('<Button>',self.on_new_config)
        self.tk_button_load_from_nsi.bind('<Button>',self.on_save)
        self.tk_button_save_config.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_button_save_config.bind('<Button>',self.on_new_config)
        self.tk_button_save_config.bind('<Button>',self.on_save)
        self.tk_button_generate_config.bind('<Button>',self.on_generate)
        self.tk_button_open_duidesigner.bind('<Button>',self.on_open_duidesigner)
        self.tk_label_frame_lg5vsexu.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_frame_lg5vsexu.bind('<Button>',self.on_new_config)
        self.tk_label_lg5t3fje.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_lg5t3fje.bind('<Button>',self.on_new_config)
        self.tk_input_product_name.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_input_product_name.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_shortcut.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_shortcut.bind('<Button>',self.on_new_config)
        self.tk_label_lg5vob16.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_label_lg5vob16.bind('<Button>',self.on_new_config)
        self.tk_input_exe_name.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_input_exe_name.bind('<Button>',self.on_new_config)
        self.tk_input_exe_name.bind('<Button>',self.on_save)
        self.tk_input_install_guid.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_input_install_guid.bind('<Button>',self.on_new_config)
        self.tk_input_install_guid.bind('<Button>',self.on_save)
        self.tk_input_product_legal.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_input_product_legal.bind('<Button>',self.on_new_config)
        self.tk_input_publisher_info.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_input_publisher_info.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_autorun.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_autorun.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_execute_level.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_execute_level.bind('<Button>',self.on_new_config)
        self.tk_select_box_combo_user.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_select_box_combo_user.bind('<Button>',self.on_new_config)
        self.tk_input_online_download_baseurl.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_input_online_download_baseurl.bind('<Button>',self.on_new_config)
        self.tk_text_lg5wph98.bind('<<ComboboxSelected>>',self.on_config_change)
        self.tk_text_lg5wph98.bind('<Button>',self.on_new_config)
        self.tk_text_lg5wph98.bind('<Button>',self.on_save)
        pass
if __name__ == "__main__":
    win = Win()
    win.mainloop()