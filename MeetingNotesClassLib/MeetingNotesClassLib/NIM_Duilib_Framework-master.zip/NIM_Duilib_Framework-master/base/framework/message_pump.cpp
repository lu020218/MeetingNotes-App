﻿// Copyright (c) 2011, NetEase Inc. All rights reserved.
//
// Author: wrt(guangguang)
// Date: 2011/6/8
//
// The base class of a cross flatform message pump implemention

#include "base/framework/message_pump.h"

namespace nbase
{

MessagePump::MessagePump()
{

}

MessagePump::~MessagePump()
{

}

} // namespace nbase
