
开启自动签名流程：
1. 将signfile.bat中的xxx.pfx改成你的证书的名称 （后续是pfx格式的）
2. 将xxx这个密码，改成你们的证书的密码
3. 将www.xxx.com替换成你们产品的网站
4. 将最后一行的@rem 删除