#!/usr/bin/python3
# coding=utf8
import argparse
import os
import sys
import util
from util import ConfigUtil
import package_util
import shutil
import json
import logging
import time

def str2bool(x):
    return x.lower() in ('true')

def prepare_arguments(parser: argparse.ArgumentParser):
    # 打包流程控制指令 
    parser.add_argument(
            "--project_name", type=str, required=True, help="the project name, eg: leeqia_moutain",
        )
    # 打包模式
    parser.add_argument(
        "--package_mode", type=int, required=True, help="the package mode, 0:7z, 1:nozip, 2: online"
        )
    # 打包过程中是否添加签名（卸载程序与最终的安装包）
    parser.add_argument(
        "--need_sign", type=str2bool, default=False, help="check if sign uninstall and setup file"
        )
    
    # 是否打Electron包
    parser.add_argument(
        "--build_for_electron", type=str2bool, default=False, help="check if build for electron, if True, we will call npm build in scripts"
        )
    # 是否从Electron配置中读取程序名称，版本号，注册表KEY等
    parser.add_argument(
        "--electron_build_path", type=str, default=None, help="electron build path, the dir path of package.json"
        )
    # 是否生成latest.xml
    parser.add_argument(
        "--generate_latest_file", type=str2bool, default=False, help="check if generate latest.xml for electron-updater"
        )
    # 待打包文件夹名称
    parser.add_argument(
        "--files_toinstall_name", type=str, default="FilesToInstall", help="local directory name for nsNiuniuSkin, FilesToInstall default"
        )
    # 是否在安装时自动写入unist.exe（不建议开启）
    parser.add_argument(
        "--auto_write_uninst", type=str2bool, default=False, help="check if generate uninstall automatically, default False"
    )
    # 卸载程序名称
    parser.add_argument(
        "--uninst_file_name", type=str, default="uninst.exe", help="the uninstall file name"
    )
    # 卸载程序名称
    parser.add_argument(
        "--src_files_dir", type=str, default=None, help="the unpacked file path, if specified, we will copy the files to [files_toinstall_name] and package them"
    )
    

    #----------------------------安装包基础信息配置--------------------------------
    
    #--------产品名称信息----------
    # 注：如果新增加了语言，需要在此处新增加产品名称，并在write_pre_define函数以及多语言翻译文件中增加处理
    # 产品名称
    parser.add_argument(
        "--PRODUCT_NAME", type=str, default=None, help="product name, if None, we will use the definition in soft_setup.nsi"
    )
    # 产品英文名称
    parser.add_argument(
        "--PRODUCT_NAME_EN", type=str, default=None, help="english product name, if None, we will use the definition in soft_setup.nsi"
    )
    

    # 安装包名称
    parser.add_argument(
        "--INSTALL_OUTPUT_NAME", type=str, default=None, help="setup file name, if None, we will use the definition in soft_setup.nsi"
    )
    # 版本号
    parser.add_argument(
        "--PRODUCT_VERSION", type=str, default=None, help="the package version, if None, we will use the definition in soft_setup.nsi"
    )
    # 主程序名称
    parser.add_argument(
        "--EXE_NAME", type=str, default=None, help="the main exe name, if None, we will use the definition in soft_setup.nsi"
    )
    # 安装路径保存在注册表中的key值，如果是Electron程序，默认是InstallLocation
    parser.add_argument(
        "--INSTALL_LOCATION_KEY", type=str, default=None, help="the install localtion key, if None, we will use the definition in soft_setup.nsi"
    )
    # 安装路径中追加的文件夹名称 
    parser.add_argument(
        "--INSTALL_APPEND_PATH", type=str, default=None, help="the append path when install, if None, we will use the definition in soft_setup.nsi"
    )
    # 此软件在注册表中的标识号
    parser.add_argument(
        "--PRODUCT_PATHNAME", type=str, default=None, help="the identity in reg, if None, we will use the definition in soft_setup.nsi"
    )
    
    # 软件默认安装路径
    parser.add_argument(
        "--INSTALL_DEFALT_SETUPPATH", type=str, default=None, help="the default setup path, if None, we will use the definition in soft_setup.nsi"
    )

    # --------------------安装包更多控制信息----------------------------------
    # 安装解压过程中是否增加等待，便于预览安装过程中的UI，实际使用应该为False
    parser.add_argument(
        "--TEST_SLEEP", type=int, default=None, help="if True, it will sleep when extract the files, if None, we will use the definition in soft_setup.nsi"
    )
    # 默认是否添加桌面快捷方式
    parser.add_argument(
        "--INSTALL_DEFAULT_SHOTCUT", type=int, default=None, help="check if add shortcut for default, if None, we will use the definition in soft_setup.nsi"
    )
    # 默认是否添加开机启动
    parser.add_argument(
        "--INSTALL_DEFAULT_AUTORUN", type=int, default=None, help="check if add auto run for default, if None, we will use the definition in soft_setup.nsi"
    )
    # 安装包默认的权限
    parser.add_argument(
        "--INSTALL_EXECUTION_LEVEL", type=str, default=None, help="execution level(admin/user), if None, we will use the definition in soft_setup.nsi"
    )
    # 是安装到所有用户，还是当前用户
    parser.add_argument(
        "--INSTALL_MODE_ALL_USERS", type=str, default=None, help="install mode(all/current), if None, we will use the definition in soft_setup.nsi"
    )

    parser.add_argument(
        "--INSTALL_DOWNLOAD_BASEURL", type=str, default=None, help="download base url for online install, if None, we will use the definition in soft_setup.nsi"
    )

    # ---------------------------更多版权信息-------------------------------
    parser.add_argument(
        "--PRODUCT_LEGAL", type=str, default=None, help="product legal, if None, we will use the definition in soft_setup.nsi"
    )

    parser.add_argument(
        "--PRODUCT_PUBLISHER", type=str, default=None, help="publisher info, if None, we will use the definition in soft_setup.nsi"
    )


if __name__ == "__main__":
    # 解析参数，设置log
    args = ConfigUtil.instance().parse_arguments(prepare_arguments)
    util.init_log(args.log_dir, "package_")
    base_dir = os.path.dirname(os.path.abspath(__file__))  
    # 判断是不是打包electron
    if args.build_for_electron:
        logging.info("build electron app")
        ret = package_util.build_for_electron(base_dir, args)
        if not ret:
            logging.error("build for electron failed")
            exit(1)
        logging.info(args.PRODUCT_VERSION)
        logging.info(args.EXE_NAME)
        logging.info(args.PRODUCT_PATHNAME)
    else:
        if args.INSTALL_OUTPUT_NAME is None:
            logging.error("install output name can not be none")
            exit(1)
        # 如果指定了外部源目录，则清空本地目录，将其中的文件复制过来
        if args.src_files_dir is not None:
            os.chdir(base_dir)
            logging.info("copy app files")
            files_toinstall_path = f"{base_dir}\{args.files_toinstall_name}"
            try:
                if os.path.exists(files_toinstall_path):
                    shutil.rmtree(files_toinstall_path)
                    os.mkdir(files_toinstall_path)
                    util.deep_copy(args.src_files_dir, files_toinstall_path)
            except Exception as e:
                logging.exception(e)
                exit(1)
    dic_output_name = {"output_name": args.INSTALL_OUTPUT_NAME}
    output_name_path = f"{base_dir}\\real_output_name.json"
    output_name_content = json.dumps(dic_output_name, indent=4, ensure_ascii=False)
    util.write_content(output_name_path, output_name_content)

    # latest_file_version 用于生成latest.xml时使用
    latest_file_version = args.PRODUCT_VERSION
    # 校正版本号
    args.PRODUCT_VERSION = package_util.adjust_version(args.PRODUCT_VERSION)
    
    # ---------- 根据配置生成公共部分的 pre_define.nsh ----------------
    logging.info("write predefines")
    package_util.write_pre_define(base_dir, args)

    # 生成语言，界面UI等
    logging.info("generate skin and language")
    ret = package_util.generate_skin_and_language(base_dir, args.project_name)
    if not ret:
        exit(1)
    
    # 根据配置，生成卸载程序并根据配置进行签名
    logging.info("generate uninstall and sign")
    ret = package_util.generate_uninstall_and_sign(base_dir, args)
    if not ret:
        exit(1)
    
    # 打最终安装包并签名
    logging.info("generate setup and sign")
    ret = package_util.generate_setup_and_sign(base_dir, args)
    if not ret:
        exit(1)
    
    # 根据配置生成latest.xml
    logging.info("generate latest.xml")
    ret = package_util.generate_latest_xml(base_dir, latest_file_version, args)
    if not ret:
        exit(1)
    logging.info("package finished")
    
