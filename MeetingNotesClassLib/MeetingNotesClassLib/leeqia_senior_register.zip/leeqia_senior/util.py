#!/usr/bin/python3

import os
import json
import sys
import time
import logging
import subprocess
import argparse
import datetime
from datetime import datetime
import shutil

class ConfigUtil:
    @classmethod
    def instance(cls, *args, **kwargs):
        if not hasattr(cls, "ins"):
            obj = cls(*args, **kwargs)
            setattr(cls, "ins", obj)
        return getattr(cls, "ins")

    def __init__(self):
        self.args = None
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument(
            "--log_dir",
            type=str,
            default=None,
            help="if None, log will be written to console",
        )

    def parse_arguments(self, prepare_func):
        """
        解析命令行参数, 如果有设置回调函数, 同时也解决回调函数中的
        """
        if prepare_func is not None:
            prepare_func(self.parser)
        self.args = self.parser.parse_args()
        return self.args


def write_content(path:str, content:str, encoding='utf-8'):
    """
    写文件
    """
    file = open(path, 'w', encoding=encoding)
    file.write(content)
    file.close()


def to_strdate(dt: datetime = None, with_spliter: bool = False) -> str:
    """
    datetime转日期字符串
    """
    if dt is None:
        dt = datetime.utcnow()
    if with_spliter:
        return dt.strftime("%Y-%m-%d")
    return dt.strftime("%Y%m%d")


def init_log(logdir: str, loghead: str):
    """
    初始化日志"""
    if logdir is None:
        logging.basicConfig(
            level=logging.INFO,
            stream=sys.stdout,
            datefmt="%Y-%m-%d %H:%M:%S",
            format="%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s",
        )
        return

    if not os.path.isdir(logdir):
        os.mkdir(logdir)
    log_dir_bak = f"{logdir}/{loghead}_bak/"
    if not os.path.isdir(log_dir_bak):
        os.mkdir(log_dir_bak)
    today = to_strdate()
    curr_log_file_name = f"{loghead}_{today}.log"
    logfilepath = f"{logdir}/{curr_log_file_name}"
    logging.basicConfig(
        level=logging.INFO,
        filename=logfilepath,
        filemode="a",
        datefmt="%Y-%m-%d %H:%M:%S",
        format="%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s",
    )
    logging.info("start")

def remove_file(file_path:str):
    """
    删除文件
    """
    if os.path.exists(file_path):
        os.remove(file_path)

def deep_copy(src_dir: str, dst_dir:str) -> bool:
    """
    复制指定目录下的所有文件到目标目录下
    """
    shutil.copytree(src_dir, dst_dir, dirs_exist_ok=True)
    return True

def run_cmd_wait_ret(command: str, show_detail: bool = False) -> bool:
    """
    调用命令, 返回其响应, 并判断返回值, 如果为0则返回true, 否则返回false
    """
    logging.info(command)
    if not show_detail:
        subp = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            encoding="utf-8",
        )
    else:
        subp = subprocess.Popen(command, shell=True, encoding="utf-8")
    subp.wait()
    ret = subp.poll()
    if ret == 0:
        return True
    return False

def get_file_count(dir_path:str):
    size = 0
    files = os.listdir(dir_path)
    for file in files:
        file_path = os.path.join(dir_path, file)
        # dir
        if os.path.isdir(file_path):
            size += get_file_count(file_path)
        # file
        elif os.path.isfile(file_path):
            size += 1
    return size

def scan_directories(dir_path: str, dic_dir:dict):
    files = os.listdir(dir_path)
    tmp = {}
    for file in files:
        file_path = os.path.join(dir_path, file)
        if os.path.isdir(file_path):
            tmp[file_path] = 1
            dic_dir[file_path] = 1
    for path in tmp.keys():
        scan_directories(path, dic_dir)